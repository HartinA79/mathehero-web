﻿namespace MatheHero.Shared.Resources.Shared.Pages.AppStart
{
    public class LoadingScreenResourceKeys
    {
        public const string LabelText = nameof(LabelText);
    }
}
