﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MatheHero.Shared.Models
{
    public class AvatarModel
    {
        public string DocumentId { get; set; }

        public string Link { get; set; }
    }
}
